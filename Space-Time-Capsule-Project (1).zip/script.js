const missions = [
 {id:"apollo",area:"moon",category:"MOON · APOLLO PROGRAM",title:"Apollo Lunar Module",year:"1969–1972",emoji:"🛸",art:"moon-art",summary:"The spacecraft that carried astronauts from lunar orbit down to the Moon's surface and back.",purpose:"The Lunar Module (LM) was designed to land two astronauts on the Moon and lift them back to the Command and Service Module in lunar orbit.",science:"Apollo crews explored the lunar surface, collected rock and soil samples, and deployed scientific experiments. The samples transformed our understanding of the Moon.",status:"The Apollo Lunar Modules used for landing were left on the Moon; they are no longer operating.",location:"Moon — Apollo landing sites",source:"https://www.nasa.gov/the-apollo-program/"},
 {id:"lr3",area:"moon",category:"MOON · SCIENCE INSTRUMENT",title:"Lunar Roving Vehicle",year:"1971–1972",emoji:"🚙",art:"moon-art",summary:"A battery-powered rover that let Apollo astronauts travel farther across the lunar surface.",purpose:"The Lunar Roving Vehicle (LRV) carried astronauts, tools and lunar samples across the Moon during Apollo 15, 16 and 17.",science:"It expanded the distance crews could explore and helped them collect samples from a wider range of lunar locations.",status:"The three LRVs remain parked on the Moon near their final Apollo locations.",location:"Moon — Apollo 15, 16 and 17 landing sites",source:"https://www.nasa.gov/mission/apollo-15/"},
 {id:"sojourner",area:"mars",category:"MARS · PATHFINDER",title:"Sojourner Rover",year:"1997",emoji:"🤖",art:"mars-art",summary:"The first successful wheeled rover to operate on Mars — a small robot with a big legacy.",purpose:"Sojourner was part of the Mars Pathfinder mission. It tested the idea of using a small mobile robot to investigate the Martian surface.",science:"It examined nearby rocks and soil and showed that a relatively small, low-cost rover could do useful science on another planet.",status:"The mission ended after communications were lost in 1997.",location:"Mars — Ares Vallis region",source:"https://science.nasa.gov/mission/mars-pathfinder/"},
 {id:"opportunity",area:"mars",category:"MARS · EXPLORATION ROVER",title:"Opportunity Rover",year:"2004–2018",emoji:"🔭",art:"mars-art",summary:"A rover designed for a 90-Martian-day mission that explored Mars for nearly 15 years.",purpose:"Opportunity was sent to study rocks and soils for clues about past water on Mars.",science:"It found strong evidence that liquid water had altered rocks at its landing site and explored the rim of Endeavour Crater.",status:"NASA declared the mission complete in February 2019 after a planet-wide dust storm ended communications in 2018.",location:"Mars — Meridiani Planum and Endeavour Crater",source:"https://science.nasa.gov/mission/mer-op-opportunity/"},
 {id:"curiosity",area:"mars",category:"MARS · SCIENCE LABORATORY",title:"Curiosity Rover",year:"2012–present*",emoji:"🛰️",art:"mars-art",summary:"A car-sized mobile laboratory investigating whether Mars once had conditions suitable for microbial life.",purpose:"Curiosity explores Gale Crater and Mount Sharp, studying rocks, soil and the Martian atmosphere.",science:"It found evidence that ancient Mars had long-lived environments with water and chemical ingredients important for life.",status:"Active mission at the time of the last verified project research. Check NASA for current status.",location:"Mars — Gale Crater",source:"https://science.nasa.gov/mission/msl-curiosity/"},
 {id:"voyager",area:"deep",category:"DEEP SPACE · INTERSTELLAR MISSION",title:"Voyager 1 & 2",year:"1977–present*",emoji:"🛰️",art:"deep-art",summary:"Twin spacecraft that explored the giant planets and continued into interstellar space.",purpose:"Voyager 1 and Voyager 2 were launched to study Jupiter and Saturn; Voyager 2 also visited Uranus and Neptune.",science:"They transformed our knowledge of the outer planets, their moons and magnetic environments. Both spacecraft later crossed the heliopause.",status:"Both continue to communicate with Earth using limited power. Check NASA's live mission updates for current instrument status.",location:"Interstellar space — beyond the heliosphere",source:"https://science.nasa.gov/mission/voyager/"},
];
const timeline = [
 ["1969","Apollo 11","Humans first land on the Moon. Apollo hardware and experiments begin a new era of lunar exploration."],
 ["1971","Lunar rover","Apollo 15 becomes the first mission to use the Lunar Roving Vehicle on the Moon."],
 ["1977","Voyager launches","Voyager 1 and 2 begin their journeys to explore the outer planets."],
 ["1997","Sojourner on Mars","The Pathfinder mission delivers the first successful Mars rover."],
 ["2004","Twin Mars rovers","Spirit and Opportunity land on Mars and begin exploring its geology."],
 ["2012","Curiosity lands","A mobile science laboratory begins investigating Gale Crater."],
 ["2021","Perseverance lands","NASA's rover begins exploring Jezero Crater and collecting samples for possible future return."]
];
const grid=document.getElementById("missionGrid");
function renderMissions(filter="all"){
 const shown=missions.filter(m=>filter==="all"||m.area===filter);
 grid.innerHTML=shown.map(m=>`<article class="mission-card" tabindex="0" role="button" aria-label="Learn about ${m.title}" data-id="${m.id}"><div class="card-art ${m.art}"><span class="card-top">${m.category}</span><span class="emoji">${m.emoji}</span></div><div class="card-content"><h3>${m.title}</h3><p>${m.summary}</p><div class="card-meta"><span>${m.year}</span><span>Explore story ↗</span></div></div></article>`).join("");
 grid.querySelectorAll(".mission-card").forEach(card=>{card.addEventListener("click",()=>openMission(card.dataset.id));card.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openMission(card.dataset.id)}})});
}
function openMission(id){
 const m=missions.find(x=>x.id===id);if(!m)return;
 document.getElementById("dialogContent").innerHTML=`<div class="dialog-content"><div class="dialog-kicker">${m.category}</div><h2>${m.emoji} ${m.title}</h2><p>${m.summary}</p><div class="dialog-facts"><div class="fact"><small>MISSION ERA</small><strong>${m.year}</strong></div><div class="fact"><small>LOCATION</small><strong>${m.location}</strong></div><div class="fact"><small>WHAT IT DID</small><strong>${m.purpose}</strong></div><div class="fact"><small>STATUS</small><strong>${m.status}</strong></div></div><h3>What did we learn?</h3><p>${m.science}</p><a class="source-link" href="${m.source}" target="_blank" rel="noopener">Read more at NASA ↗</a></div>`;
 document.getElementById("missionDialog").showModal();
}
renderMissions();
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");renderMissions(btn.dataset.filter)}));
document.getElementById("dialogClose").addEventListener("click",()=>document.getElementById("missionDialog").close());
document.getElementById("missionDialog").addEventListener("click",e=>{if(e.target.id==="missionDialog")e.target.close()});
document.getElementById("timelineItems").innerHTML=timeline.map(t=>`<article class="timeline-item"><strong>${t[0]}</strong><h3>${t[1]}</h3><p>${t[2]}</p></article>`).join("");
const questions=[
 {q:"Which machine carried astronauts from lunar orbit down to the Moon?",a:["Voyager spacecraft","Apollo Lunar Module","Sojourner rover"],correct:1,why:"The Apollo Lunar Module was designed to land astronauts on the Moon and return them to lunar orbit."},
 {q:"What was Sojourner famous for?",a:["Being the first successful Mars rover","Visiting Saturn","Taking humans to the Moon"],correct:0,why:"Sojourner was the small rover delivered by Mars Pathfinder in 1997."},
 {q:"Which rover was designed to study whether ancient Mars had environments suitable for microbial life?",a:["Lunar Roving Vehicle","Curiosity","Voyager 2"],correct:1,why:"Curiosity studies the habitability of ancient environments in Gale Crater."},
 {q:"Where did Voyager 1 and 2 travel after their planetary encounters?",a:["Into interstellar space","To the surface of the Sun","Back to the Moon"],correct:0,why:"Both Voyager spacecraft crossed the heliopause and entered interstellar space."}
];
let qIndex=0,score=0,answered=false;
function showQuestion(){
 const q=questions[qIndex];answered=false;
 document.getElementById("quizProgress").style.width=((qIndex+1)/questions.length*100)+"%";
 document.getElementById("questionCount").textContent=`QUESTION ${qIndex+1} OF ${questions.length}`;
 document.getElementById("quizCard").innerHTML=`<div class="q-label">QUESTION ${qIndex+1}</div><h3>${q.q}</h3><div class="answers">${q.a.map((a,i)=>`<button class="answer" data-answer="${i}">${String.fromCharCode(65+i)}. &nbsp;${a}</button>`).join("")}</div><p class="feedback" aria-live="polite"></p><button class="quiz-next" disabled> ${qIndex===questions.length-1?"See my result":"Next question →"}</button>`;
 const card=document.getElementById("quizCard");
 card.querySelectorAll(".answer").forEach(b=>b.addEventListener("click",()=>{if(answered)return;answered=true;const selected=Number(b.dataset.answer);if(selected===q.correct)score++;card.querySelectorAll(".answer").forEach((x,i)=>{x.disabled=true;if(i===q.correct)x.classList.add("correct");else if(i===selected)x.classList.add("wrong")});card.querySelector(".feedback").textContent=(selected===q.correct?"Correct! ":"Not quite. ")+q.why;card.querySelector(".quiz-next").disabled=false}));
 card.querySelector(".quiz-next").addEventListener("click",()=>{if(!answered)return;if(qIndex<questions.length-1){qIndex++;showQuestion()}else showResult()});
}
function showResult(){document.getElementById("questionCount").textContent="MISSION COMPLETE";document.getElementById("quizProgress").style.width="100%";document.getElementById("quizCard").innerHTML=`<div class="q-label">YOUR MISSION REPORT</div><h3>You scored ${score} out of ${questions.length}!</h3><p>${score===4?"Outstanding, Space Explorer!":score>=2?"Great work! Keep exploring and learning.":"Every explorer learns by asking questions. Try again!"}</p><button class="quiz-next" id="retryQuiz">Try again ↻</button>`;document.getElementById("retryQuiz").addEventListener("click",()=>{qIndex=0;score=0;showQuestion()})}
showQuestion();
const menu=document.getElementById("menuToggle"),nav=document.getElementById("mainNav");
menu.addEventListener("click",()=>{const open=nav.classList.toggle("open");menu.setAttribute("aria-expanded",String(open))});
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");menu.setAttribute("aria-expanded","false")}));
