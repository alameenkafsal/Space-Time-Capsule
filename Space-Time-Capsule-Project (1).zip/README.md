# Space Time Capsule 🚀

An interactive, child-friendly educational website about NASA space hardware left on the Moon, operating on Mars, and travelling through deep space.

## Features
- Responsive landing page and mission archive
- Filter missions by Moon, Mars and deep space
- Mission detail pop-ups with purpose, science, location, status and NASA source links
- Exploration timeline
- Destination overview (not a live tracking map)
- Four-question interactive quiz with score and feedback
- Mobile navigation and keyboard-accessible mission cards

## Run locally
Open `index.html` in a modern browser. No build tools or dependencies are required.

## Publish with GitHub Pages
1. Open repository **Settings → Pages**.
2. Under **Build and deployment**, choose **Deploy from a branch**.
3. Choose branch `main` and folder `/ (root)`, then Save.
4. Wait for GitHub Pages to publish the site.

## Project structure
```text
Space-Time-Capsule/
├── assets/
│   └── icons/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Research and accuracy notes
The site is an educational overview, not a live telemetry dashboard. Some mission statuses can change; the Voyager and Curiosity status labels are intentionally qualified and visitors are directed to NASA's mission pages for current information. Mission facts are summarized in student-friendly language.

NASA reference pages:
- [Apollo program](https://www.nasa.gov/the-apollo-program/)
- [Apollo 15](https://www.nasa.gov/mission/apollo-15/)
- [Mars Pathfinder](https://science.nasa.gov/mission/mars-pathfinder/)
- [Mars Exploration Rover – Opportunity](https://science.nasa.gov/mission/mer-op-opportunity/)
- [Mars Science Laboratory – Curiosity](https://science.nasa.gov/mission/msl-curiosity/)
- [Voyager](https://science.nasa.gov/mission/voyager/)

## Important before submission
- Verify every mission's current operational status on NASA pages close to submission time.
- Add team members' names and project credits.
- Follow the official NASA Space Apps 2026 challenge and submission rules.
- Do not describe the destination overview as a real-time map.
